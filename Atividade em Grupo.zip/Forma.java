public abstract class Forma {
    protected String cor;

    public Forma(String cor) throws CorInvalidaException {
        if (cor == null || cor.trim().isEmpty()) {
            throw new CorInvalidaException(cor);
        }
        this.cor = cor;
    }

    public String getCor() {
        return cor;
    }

    public abstract double calcularArea();
    public abstract double calcularPerimetro();

    public final void verificarAreaPositiva() {
        double area = calcularArea();
        assert area > 0 : "Erro: área não é positiva! Valor calculado: " + area;
    }
}
