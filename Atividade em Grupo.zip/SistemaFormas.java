public class SistemaFormas {

    public static void main(String[] args) {
        try {
            // Exemplo que gera exceção de cor inválida
            Forma f1 = new Circulo("", 10);
        } catch (CorInvalidaException | DimensaoInvalidaException e) {
            System.out.println("Erro ao criar forma: " + e.getMessage());
        } finally {
            System.out.println("Tentativa de criação de forma concluída.\n");
        }

        try {
            // Exemplo de forma válida
            Forma f2 = new Retangulo("Azul", 5, 3);
            f2.verificarAreaPositiva();
            System.out.println("Forma criada com sucesso: " + f2.getCor());
            System.out.println("Área: " + f2.calcularArea());
            System.out.println("Perímetro: " + f2.calcularPerimetro());
        } catch (Exception e) {
            System.out.println("Erro inesperado: " + e.getMessage());
        }

        // Simulação de falha no sistema
        try {
            simularFalha();
        } catch (ExcecaoSimuladaDoSistema e) {
            System.out.println("\nExceção capturada: " + e.getMessage());
        }
    }

    public static void simularFalha() {
        throw new ExcecaoSimuladaDoSistema("Erro de execução não verificado.");
    }
}
