public class Retangulo extends Forma {
    private double largura;
    private double altura;

    public Retangulo(String cor, double largura, double altura)
            throws CorInvalidaException, DimensaoInvalidaException {
        super(cor);
        if (largura <= 0 || altura <= 0) {
            throw new DimensaoInvalidaException("largura = " + largura + ", altura = " + altura);
        }
        this.largura = largura;
        this.altura = altura;
    }

    @Override
    public double calcularArea() {
        return largura * altura;
    }

    @Override
    public double calcularPerimetro() {
        return 2 * (largura + altura);
    }
}
