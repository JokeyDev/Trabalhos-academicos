public class CorInvalidaException extends Exception {
    public CorInvalidaException(String cor) {
        super("Cor inválida fornecida: '" + cor + "'. A cor não pode ser nula ou vazia.");
    }
}
