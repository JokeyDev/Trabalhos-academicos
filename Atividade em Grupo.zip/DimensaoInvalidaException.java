public class DimensaoInvalidaException extends Exception {
    public DimensaoInvalidaException(String mensagem) {
        super("Dimensão inválida: " + mensagem + ". O valor deve ser maior que zero.");
    }
}
