public class Circulo extends Forma {
    private double raio;

    public Circulo(String cor, double raio) throws CorInvalidaException, DimensaoInvalidaException {
        super(cor);
        if (raio <= 0) {
            throw new DimensaoInvalidaException("raio = " + raio);
        }
        this.raio = raio;
    }

    @Override
    public double calcularArea() {
        return Math.PI * raio * raio;
    }

    @Override
    public double calcularPerimetro() {
        return 2 * Math.PI * raio;
    }
}
