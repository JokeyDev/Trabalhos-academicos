public class ExcecaoSimuladaDoSistema extends RuntimeException {
    public ExcecaoSimuladaDoSistema(String mensagem) {
        super("Falha simulada do sistema: " + mensagem);
    }
}
